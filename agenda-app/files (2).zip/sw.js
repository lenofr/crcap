// sw.js — CRCAP Agenda PWA Service Worker
const CACHE = 'crcap-agenda-v1';
const OFFLINE_URL = '/crcap/agenda-app/';

self.addEventListener('install', e => {
    e.waitUntil(
        caches.open(CACHE).then(c => c.addAll([OFFLINE_URL]))
    );
    self.skipWaiting();
});

self.addEventListener('activate', e => {
    e.waitUntil(
        caches.keys().then(keys =>
            Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
        )
    );
    self.clients.claim();
});

self.addEventListener('fetch', e => {
    if (e.request.method !== 'GET') return;
    e.respondWith(
        fetch(e.request)
            .then(r => {
                const clone = r.clone();
                caches.open(CACHE).then(c => c.put(e.request, clone));
                return r;
            })
            .catch(() => caches.match(e.request).then(r => r || caches.match(OFFLINE_URL)))
    );
});

// Push notifications
self.addEventListener('push', e => {
    const data = e.data?.json() ?? { title: 'CRCAP Agenda', body: 'Nova atualização na agenda.' };
    e.waitUntil(
        self.registration.showNotification(data.title, {
            body: data.body,
            icon: '/crcap/agenda-app/icon-192.png',
            badge: '/crcap/agenda-app/icon-192.png',
            tag: 'crcap-agenda',
            vibrate: [200, 100, 200],
            data: { url: '/crcap/agenda-app/' }
        })
    );
});

self.addEventListener('notificationclick', e => {
    e.notification.close();
    e.waitUntil(clients.openWindow(e.notification.data?.url ?? '/crcap/agenda-app/'));
});
